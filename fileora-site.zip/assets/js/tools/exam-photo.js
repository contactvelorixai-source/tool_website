/* Exam photo & signature resizer: exact pixel size + KB range for Indian exam forms */
(function () {
  // Typical requirements. Notifications change, so every number stays editable.
  const PRESETS = {
    ssc: { photo: [350, 450, 20, 50], sign: [400, 200, 10, 20] },
    bank: { photo: [200, 230, 20, 50], sign: [140, 60, 10, 20] },
    nta: { photo: [413, 531, 10, 200], sign: [400, 150, 4, 30] },
    rrb: { photo: [413, 531, 30, 70], sign: [472, 236, 30, 70] },
    upsc: { photo: [500, 500, 20, 300], sign: [500, 250, 20, 300] },
    custom: { photo: [350, 450, 20, 50], sign: [400, 200, 10, 20] }
  };
  const $ = id => document.getElementById(id);
  const ws = $("ws"), drop = $("drop"), list = $("list"), exam = $("exam");
  const seg = FY.segs((n) => { if (n === "doc") fill(); });
  let img = null, file = null;

  function fill() {
    const p = PRESETS[exam.value][seg.doc];
    [$("w").value, $("h").value, $("minKb").value, $("maxKb").value] = p;
    $("cleanWrap").hidden = seg.doc !== "sign";
  }
  exam.addEventListener("change", fill);

  async function take(files) {
    file = files[0];
    try { img = await FY.loadImage(file); } catch (e) { return FY.toast(e.message, true); }
    list.innerHTML = "";
    list.appendChild(FY.fileRow({ name: file.name, thumb: img.src, sub: FY.fmtBytes(file.size) + " · " + img.naturalWidth + " × " + img.naturalHeight }, 0, 1, { remove: () => { img = null; ws.hidden = true; drop.hidden = false; } }));
    ws.hidden = false; drop.hidden = true; $("result").hidden = true;
  }

  function render(W, H) {
    const c = document.createElement("canvas");
    c.width = W; c.height = H;
    const ctx = c.getContext("2d");
    ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, W, H);
    ctx.imageSmoothingQuality = "high";
    // cover: crop the centre to the target shape
    const r = Math.max(W / img.naturalWidth, H / img.naturalHeight);
    const dw = img.naturalWidth * r, dh = img.naturalHeight * r;
    ctx.drawImage(img, (W - dw) / 2, (H - dh) / 2, dw, dh);
    if (seg.doc === "sign" && $("clean").checked) {
      const d = ctx.getImageData(0, 0, W, H), a = d.data;
      let sum = 0;
      for (let i = 0; i < a.length; i += 4) sum += 0.3 * a[i] + 0.59 * a[i + 1] + 0.11 * a[i + 2];
      const thr = Math.min(200, (sum / (a.length / 4)) * 0.82);
      for (let i = 0; i < a.length; i += 4) {
        const l = 0.3 * a[i] + 0.59 * a[i + 1] + 0.11 * a[i + 2];
        if (l > thr) { a[i] = a[i + 1] = a[i + 2] = 255; }
        else { const k = 0.45; a[i] *= k; a[i + 1] *= k; a[i + 2] *= k; }
      }
      ctx.putImageData(d, 0, 0);
    }
    return c;
  }

  /* Pad a JPEG with comment segments so it meets a minimum file size (the picture does not change) */
  async function padTo(blob, minBytes) {
    const buf = new Uint8Array(await blob.arrayBuffer());
    let need = minBytes - buf.length + 64;
    if (need <= 0) return blob;
    const parts = [buf.slice(0, 2)];
    while (need > 0) {
      const len = Math.min(65533, Math.max(16, need));
      const seg = new Uint8Array(len + 4);
      seg[0] = 0xff; seg[1] = 0xfe; seg[2] = ((len + 2) >> 8) & 0xff; seg[3] = (len + 2) & 0xff;
      for (let i = 4; i < seg.length; i++) seg[i] = 0x20;
      parts.push(seg); need -= len + 4;
    }
    parts.push(buf.slice(2));
    return new Blob(parts, { type: "image/jpeg" });
  }

  async function run() {
    if (!img) return;
    const W = Math.round(+$("w").value), H = Math.round(+$("h").value);
    const minB = (+$("minKb").value || 0) * 1024, maxB = (+$("maxKb").value || 0) * 1024;
    if (!(W >= 20 && H >= 20 && W <= 5000 && H <= 5000)) return FY.toast("Enter a width and height between 20 and 5000 pixels.", true);
    if (!maxB || (minB && minB >= maxB)) return FY.toast("Set a maximum KB that is larger than the minimum.", true);
    const btn = $("go"); btn.disabled = true;
    try {
      const c = render(W, H);
      let lo = 0.1, hi = 0.98, fit = null;
      for (let k = 0; k < 9; k++) {
        const mid = (lo + hi) / 2, b = await FY.canvasToBlob(c, "image/jpeg", mid);
        if (b.size <= maxB) { fit = b; lo = mid; } else hi = mid;
      }
      const top = await FY.canvasToBlob(c, "image/jpeg", 0.98);
      if (top.size <= maxB) fit = top;
      let note = "";
      if (!fit) { fit = await FY.canvasToBlob(c, "image/jpeg", 0.1); note = "Even at the lowest quality this is above " + (maxB / 1024) + " KB. Try a smaller width and height."; }
      if (minB && fit.size < minB) fit = await padTo(fit, minB);
      const kb = (fit.size / 1024).toFixed(1);
      const name = (seg.doc === "sign" ? "signature" : "photo") + "-" + W + "x" + H + ".jpg";
      const url = URL.createObjectURL(fit);
      const r = FY.showResult('<div class="exam-out"><img alt="Resized ' + (seg.doc === "sign" ? "signature" : "photo") + '" src="' + url + '"><div><h3>Ready for your form</h3><p class="muted">' + W + " × " + H + " px · <b>" + kb + " KB</b> · JPG" +
        (note ? "<br>" + note : "<br>Fits the " + (minB / 1024) + "–" + (maxB / 1024) + " KB range.") + '</p><button class="btn btn-primary btn-lg" id="dl">Download JPG</button></div></div>');
      r.querySelector("#dl").addEventListener("click", () => FY.download(fit, name));
      FY.download(fit, name);
      if (!note) FY.confetti();
    } catch (e) { FY.toast("Could not resize: " + e.message, true); }
    finally { btn.disabled = false; }
  }

  const p = FY.preset();
  if (p.exam) exam.value = p.exam;
  if (p.doc && p.doc !== seg.doc) seg.set("doc", p.doc); else fill();
  FY.dropzone(drop, { accept: ["image/*", ".heic", ".heif"], multiple: false, label: "a JPG or PNG image", onFiles: take });
  $("go").addEventListener("click", run);
})();
