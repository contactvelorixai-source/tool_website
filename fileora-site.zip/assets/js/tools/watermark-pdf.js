/* Add a text watermark and/or page numbers to a PDF with pdf-lib */
(function () {
  const KEY = "wm", LIMIT = 1;
  const $ = id => document.getElementById(id);
  const ws = $("ws"), drop = $("drop"), list = $("list");
  const seg = FY.segs((n) => { if (n === "mode") show(); });
  let file = null, bytes = null;
  const showLeft = () => { $("left").textContent = FY.isPro() ? "Unlimited (Pro)" : Math.max(0, LIMIT - FY.usesToday(KEY)); };
  function show() {
    document.querySelector('[data-m="wm"]').hidden = seg.mode === "num";
    document.querySelector('[data-m="num"]').hidden = seg.mode === "wm";
  }
  [["wmSize", "wsv"], ["wmOp", "wov"]].forEach(([i, o]) => $(i).addEventListener("input", () => { $(o).textContent = $(i).value; }));

  async function take(files) {
    file = files[0];
    bytes = new Uint8Array(await file.arrayBuffer());
    let n = 0;
    try { n = (await PDFLib.PDFDocument.load(bytes, { ignoreEncryption: true })).getPageCount(); }
    catch (e) { return FY.toast("Could not open this PDF. It may be damaged or password protected.", true); }
    list.innerHTML = "";
    list.appendChild(FY.fileRow({ name: file.name, ext: "PDF", sub: n + " page(s) · " + FY.fmtBytes(file.size) }, 0, 1, { remove: () => { file = null; ws.hidden = true; drop.hidden = false; } }));
    ws.hidden = false; drop.hidden = true; $("result").hidden = true;
  }

  /* Text rendered to a PNG so any language (Hindi, Tamil, emoji) works */
  async function textImage(doc, text, pt, color) {
    const px = pt * 3, c = document.createElement("canvas"), ctx = c.getContext("2d");
    const f = "bold " + px + "px system-ui, 'Segoe UI', Roboto, 'Noto Sans', Arial, sans-serif";
    ctx.font = f;
    c.width = Math.ceil(ctx.measureText(text).width + px * 0.4); c.height = Math.ceil(px * 1.35);
    ctx.font = f; ctx.fillStyle = color; ctx.textBaseline = "middle"; ctx.fillText(text, px * 0.2, c.height / 2);
    const img = await doc.embedPng(c.toDataURL("image/png"));
    return { img, w: c.width / 3, h: c.height / 3 };
  }

  function stamp(pg, t, cx, cy, deg, opacity) {
    const th = deg * Math.PI / 180, cos = Math.cos(th), sin = Math.sin(th);
    pg.drawImage(t.img, {
      x: cx - (t.w / 2 * cos - t.h / 2 * sin), y: cy - (t.w / 2 * sin + t.h / 2 * cos),
      width: t.w, height: t.h, rotate: PDFLib.degrees(deg), opacity
    });
  }

  async function run() {
    if (!file) return;
    const wantWm = seg.mode !== "num", wantNum = seg.mode !== "wm";
    const text = $("wmText").value.trim();
    if (wantWm && !text) return FY.toast("Type the watermark text first.", true);
    if (!FY.canUse(KEY, LIMIT)) return FY.upgrade("You have used today's free watermark. Pro gives unlimited watermarks, page numbers and signed PDFs, with no ads.");
    const btn = $("go"); btn.disabled = true; FY.progress(0);
    try {
      const doc = await PDFLib.PDFDocument.load(bytes, { ignoreEncryption: true });
      const pagesArr = doc.getPages(), total = pagesArr.length;
      const font = await doc.embedFont(PDFLib.StandardFonts.Helvetica);
      const t = wantWm ? await textImage(doc, text, +$("wmSize").value, $("wmColor").value) : null;
      const opacity = +$("wmOp").value / 100;
      const start = +$("numStart").value || 1;
      pagesArr.forEach((pg, i) => {
        const cb = pg.getCropBox(), cx = cb.x + cb.width / 2, cy = cb.y + cb.height / 2;
        if (t) {
          if (seg.wmPos === "center") stamp(pg, t, cx, cy, 0, opacity);
          else if (seg.wmPos === "diag") stamp(pg, t, cx, cy, Math.atan2(cb.height, cb.width) * 180 / Math.PI, opacity);
          else {
            const sx = t.w * 1.25 + 40, sy = t.h * 3.2 + 40;
            for (let y = cb.y - sy; y < cb.y + cb.height + sy; y += sy)
              for (let x = cb.x - sx / 2 + ((Math.round((y - cb.y) / sy) % 2) * sx / 2); x < cb.x + cb.width + sx; x += sx)
                stamp(pg, t, x, y, 30, opacity);
          }
        }
        if (wantNum) {
          const label = seg.numFmt === "pn" ? "Page " + (start + i) + " of " + (start + total - 1) : String(start + i);
          const size = 11, tw = font.widthOfTextAtSize(label, size);
          const x = seg.numPos === "bc" ? cx - tw / 2 : cb.x + cb.width - tw - 36;
          const y = seg.numPos === "tr" ? cb.y + cb.height - 30 : cb.y + 22;
          pg.drawText(label, { x, y, size, font, color: PDFLib.rgb(0.2, 0.2, 0.25) });
        }
        FY.progress((i + 1) / total);
      });
      const blob = new Blob([await doc.save()], { type: "application/pdf" });
      FY.progress(null);
      FY.recordUse(KEY); showLeft();
      const name = FY.baseName(file.name) + (wantWm ? "-watermarked" : "-numbered") + ".pdf";
      const r = FY.showResult("<h3>Done!</h3><p class=\"muted\">" + total + " page(s) · " + (wantWm ? "watermark" : "") + (wantWm && wantNum ? " + " : "") + (wantNum ? "page numbers" : "") + " added</p><button class=\"btn btn-primary btn-lg\" id=\"dl\">Download PDF</button>");
      r.querySelector("#dl").addEventListener("click", () => FY.download(blob, name));
      FY.download(blob, name);
      FY.confetti();
    } catch (e) { FY.progress(null); FY.toast("Could not update the PDF: " + e.message, true); }
    finally { btn.disabled = false; }
  }

  const p = FY.preset();
  if (p.mode) seg.set("mode", p.mode);
  show(); showLeft();
  FY.dropzone(drop, { accept: ["application/pdf", ".pdf"], multiple: false, label: "a PDF file", onFiles: take });
  $("go").addEventListener("click", run);
})();
