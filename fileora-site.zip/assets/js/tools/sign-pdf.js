/* Sign PDF: draw / type / upload a signature, tap pages to place it, save with pdf-lib */
(function () {
  const root = document.documentElement.dataset.root || "";
  pdfjsLib.GlobalWorkerOptions.workerSrc = root + "assets/vendor/pdf.worker.min.js";
  const KEY = "sign", LIMIT = 1;
  const $ = id => document.getElementById(id);
  const ws = $("ws"), drop = $("drop"), list = $("list"), wrap = $("pages"), pad = $("pad"), size = $("sigSize");
  const FONTS = ["'Brush Script MT', 'Segoe Script', cursive", "'Segoe Script', 'Lucida Handwriting', cursive", "'Lucida Handwriting', 'Comic Sans MS', cursive", "Georgia, 'Times New Roman', serif"];
  let font = FONTS[0], upImg = null, file = null, bytes = null, pages = [], placed = [], inked = false;
  const seg = FY.segs((n) => { if (n === "smode") document.querySelectorAll("[data-sm]").forEach(el => { el.hidden = el.dataset.sm !== seg.smode; }); });
  const showLeft = () => { $("left").textContent = FY.isPro() ? "Unlimited (Pro)" : Math.max(0, LIMIT - FY.usesToday(KEY)); };
  showLeft();

  // --- signature pad
  const pctx = pad.getContext("2d");
  let drawing = false, last = null;
  const pos = e => { const r = pad.getBoundingClientRect(); return [(e.clientX - r.left) * pad.width / r.width, (e.clientY - r.top) * pad.height / r.height]; };
  pad.addEventListener("pointerdown", e => { e.preventDefault(); pad.setPointerCapture(e.pointerId); drawing = true; last = pos(e); });
  pad.addEventListener("pointermove", e => {
    if (!drawing) return;
    const p = pos(e);
    pctx.strokeStyle = "#000"; pctx.lineWidth = 4; pctx.lineCap = pctx.lineJoin = "round";
    pctx.beginPath(); pctx.moveTo(last[0], last[1]); pctx.lineTo(p[0], p[1]); pctx.stroke();
    last = p; inked = true;
  });
  ["pointerup", "pointercancel"].forEach(ev => pad.addEventListener(ev, () => { drawing = false; }));
  $("padClear").addEventListener("click", () => { pctx.clearRect(0, 0, pad.width, pad.height); inked = false; });

  // --- typed fonts
  const fonts = $("fonts");
  FONTS.forEach((f, i) => {
    const b = document.createElement("button");
    b.type = "button"; b.className = "chip"; b.style.fontFamily = f; b.style.fontSize = "1.15rem";
    b.textContent = "Signature"; b.setAttribute("aria-pressed", i === 0);
    b.addEventListener("click", () => { font = f; fonts.querySelectorAll(".chip").forEach(x => x.setAttribute("aria-pressed", x === b)); });
    fonts.appendChild(b);
  });
  $("sigFile").addEventListener("change", async e => {
    const f = e.target.files[0]; if (!f) return;
    try { upImg = await FY.loadImage(f); } catch (err) { FY.toast(err.message, true); }
  });

  /* Returns a trimmed, transparent PNG canvas of the current signature, or null */
  function signature() {
    let c = document.createElement("canvas"), ctx;
    const tint = seg.smode !== "upload";
    if (seg.smode === "draw") {
      if (!inked) return null;
      c.width = pad.width; c.height = pad.height; ctx = c.getContext("2d"); ctx.drawImage(pad, 0, 0);
    } else if (seg.smode === "type") {
      const t = $("sigText").value.trim(); if (!t) return null;
      c.width = 900; c.height = 240; ctx = c.getContext("2d");
      ctx.font = (font.startsWith("Georgia") ? "italic " : "") + "120px " + font; ctx.textBaseline = "middle"; ctx.fillStyle = "#000";
      ctx.fillText(t, 20, 125, 860);
    } else {
      if (!upImg) return null;
      const s = Math.min(1, 1000 / upImg.naturalWidth);
      c.width = upImg.naturalWidth * s; c.height = upImg.naturalHeight * s; ctx = c.getContext("2d");
      ctx.drawImage(upImg, 0, 0, c.width, c.height);
    }
    const d = ctx.getImageData(0, 0, c.width, c.height), a = d.data;
    const ink = seg.ink, ir = parseInt(ink.slice(1, 3), 16), ig = parseInt(ink.slice(3, 5), 16), ib = parseInt(ink.slice(5, 7), 16);
    let x0 = c.width, y0 = c.height, x1 = -1, y1 = -1;
    for (let y = 0; y < c.height; y++) for (let x = 0; x < c.width; x++) {
      const i = (y * c.width + x) * 4;
      if (!tint) { const l = 0.3 * a[i] + 0.59 * a[i + 1] + 0.11 * a[i + 2]; if (l > 200) a[i + 3] = 0; }
      if (a[i + 3] > 20) {
        if (tint) { a[i] = ir; a[i + 1] = ig; a[i + 2] = ib; }
        if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y;
      }
    }
    if (x1 < 0) return null;
    ctx.putImageData(d, 0, 0);
    const out = document.createElement("canvas");
    out.width = x1 - x0 + 9; out.height = y1 - y0 + 9;
    out.getContext("2d").drawImage(c, x0 - 4, y0 - 4, out.width, out.height, 0, 0, out.width, out.height);
    return out;
  }

  // --- PDF pages
  async function take(files) {
    file = files[0];
    bytes = new Uint8Array(await file.arrayBuffer());
    let pdf;
    try { pdf = await pdfjsLib.getDocument({ data: bytes.slice() }).promise; }
    catch (e) { return FY.toast(/password/i.test(e.message) ? "This PDF is password protected. Remove the password and try again." : "Could not open this PDF. It may be damaged.", true); }
    list.innerHTML = "";
    list.appendChild(FY.fileRow({ name: file.name, ext: "PDF", sub: pdf.numPages + " page(s) · " + FY.fmtBytes(file.size) }, 0, 1, { remove: () => { file = null; ws.hidden = true; drop.hidden = false; wrap.innerHTML = ""; } }));
    ws.hidden = false; drop.hidden = true; $("result").hidden = true;
    wrap.innerHTML = ""; pages = []; placed = [];
    FY.progress(0);
    const maxW = Math.min(820, wrap.clientWidth || 820);
    for (let n = 1; n <= pdf.numPages; n++) {
      const page = await pdf.getPage(n);
      const vp1 = page.getViewport({ scale: 1 });
      const sc = maxW / vp1.width, dpr = Math.min(2, window.devicePixelRatio || 1);
      const vp = page.getViewport({ scale: sc * dpr });
      const el = document.createElement("div");
      el.className = "sign-page";
      const c = document.createElement("canvas");
      c.width = Math.floor(vp.width); c.height = Math.floor(vp.height);
      c.style.width = "100%"; c.setAttribute("aria-label", "Page " + n);
      const ctx = c.getContext("2d"); ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, c.width, c.height);
      await page.render({ canvasContext: ctx, viewport: vp }).promise;
      el.appendChild(c);
      const lbl = document.createElement("span"); lbl.className = "pg-no"; lbl.textContent = "Page " + n + " / " + pdf.numPages; el.appendChild(lbl);
      const idx = n - 1;
      el.addEventListener("click", e => { if (!e.target.closest(".placed")) place(idx, e); });
      wrap.appendChild(el);
      pages.push({ el, rot: page.rotate });
      FY.progress(n / pdf.numPages);
    }
    FY.progress(null);
    await pdf.destroy();
  }

  function place(idx, e) {
    const sig = signature();
    if (!sig) return FY.toast("Create your signature first: draw it, type your name or upload an image.", true);
    const el = pages[idx].el, r = el.getBoundingClientRect();
    const wr = 0.28 * (+size.value / 100), aspect = sig.height / sig.width;
    const hr = wr * aspect * (r.width / r.height);
    const item = { page: idx, url: sig.toDataURL("image/png"), aspect, wr, xr: Math.min(1 - wr, Math.max(0, (e.clientX - r.left) / r.width - wr / 2)), yr: Math.min(1 - hr, Math.max(0, (e.clientY - r.top) / r.height - hr / 2)) };
    const d = document.createElement("div");
    d.className = "placed";
    d.innerHTML = '<img alt="Your signature"><button type="button" class="mini" aria-label="Remove signature">✕</button>';
    d.querySelector("img").src = item.url;
    d.querySelector("button").addEventListener("click", ev => { ev.stopPropagation(); d.remove(); placed = placed.filter(p => p !== item); });
    item.node = d; el.appendChild(d); placed.push(item); paint(item);
    let st = null;
    d.addEventListener("pointerdown", ev => {
      if (ev.target.closest("button")) return;
      ev.preventDefault(); d.setPointerCapture(ev.pointerId);
      st = { x: ev.clientX, y: ev.clientY, xr: item.xr, yr: item.yr };
    });
    d.addEventListener("pointermove", ev => {
      if (!st) return;
      const rr = el.getBoundingClientRect(), h = item.wr * item.aspect * (rr.width / rr.height);
      item.xr = Math.min(1 - item.wr, Math.max(0, st.xr + (ev.clientX - st.x) / rr.width));
      item.yr = Math.min(1 - h, Math.max(0, st.yr + (ev.clientY - st.y) / rr.height));
      paint(item);
    });
    ["pointerup", "pointercancel"].forEach(ev => d.addEventListener(ev, () => { st = null; }));
  }
  function paint(it) { Object.assign(it.node.style, { left: it.xr * 100 + "%", top: it.yr * 100 + "%", width: it.wr * 100 + "%" }); }
  size.addEventListener("input", () => {
    $("ssv").textContent = size.value;
    placed.forEach(it => { it.wr = 0.28 * (+size.value / 100); it.xr = Math.min(it.xr, 1 - it.wr); paint(it); });
  });

  async function run() {
    if (!file) return;
    if (!placed.length) return FY.toast("Tap a page to place your signature first.", true);
    if (!FY.canUse(KEY, LIMIT)) return FY.upgrade("You have used today's free signed PDF. Pro lets you sign unlimited PDFs, add page numbers and watermarks, and removes ads.");
    const btn = $("go"); btn.disabled = true;
    try {
      const doc = await PDFLib.PDFDocument.load(bytes, { ignoreEncryption: true });
      const cache = {};
      for (const it of placed) {
        const img = cache[it.url] || (cache[it.url] = await doc.embedPng(it.url));
        const pg = doc.getPage(it.page), cb = pg.getCropBox();
        const rot = ((pages[it.page].rot || 0) % 360 + 360) % 360;
        const vw = rot % 180 ? cb.height : cb.width, vh = rot % 180 ? cb.width : cb.height;
        const w = it.wr * vw, h = w * it.aspect;
        const vx = it.xr * vw, vy = it.yr * vh; // top-left in the viewed (rotated) page
        let x, y, deg = 0;
        if (rot === 0) { x = cb.x + vx; y = cb.y + cb.height - vy - h; }
        else if (rot === 90) { x = cb.x + vy; y = cb.y + vx; deg = 90; x += h; }
        else if (rot === 180) { x = cb.x + cb.width - vx; y = cb.y + vy + h; deg = 180; }
        else { x = cb.x + cb.width - vy - h; y = cb.y + cb.height - vx; deg = 270; }
        pg.drawImage(img, { x, y, width: w, height: h, rotate: PDFLib.degrees(deg) });
      }
      const blob = new Blob([await doc.save()], { type: "application/pdf" });
      FY.recordUse(KEY); showLeft();
      const name = FY.baseName(file.name) + "-signed.pdf";
      const r = FY.showResult('<h3>Signed!</h3><p class="muted">' + placed.length + " signature(s) added · " + FY.fmtBytes(blob.size) + '</p><button class="btn btn-primary btn-lg" id="dl">Download signed PDF</button>');
      r.querySelector("#dl").addEventListener("click", () => FY.download(blob, name));
      FY.download(blob, name);
      FY.confetti();
    } catch (e) { FY.toast("Could not sign the PDF: " + e.message, true); }
    finally { btn.disabled = false; }
  }

  FY.dropzone(drop, { accept: ["application/pdf", ".pdf"], multiple: false, label: "a PDF file", onFiles: take });
  $("go").addEventListener("click", run);
})();
