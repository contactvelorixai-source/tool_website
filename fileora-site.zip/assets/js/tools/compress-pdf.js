/* Compress PDF: re-render each page as a JPEG at a lower resolution (pdf.js) and rebuild with pdf-lib */
(function () {
  const root = document.documentElement.dataset.root || "";
  pdfjsLib.GlobalWorkerOptions.workerSrc = root + "assets/vendor/pdf.worker.min.js";
  const ws = document.getElementById("ws"), drop = document.getElementById("drop"), list = document.getElementById("list");
  const target = document.getElementById("targetKb");
  const seg = FY.segs();
  // [render scale (1 = 72 DPI), JPEG quality]
  const LEVELS = { low: [1.6, 0.78], rec: [1.3, 0.62], max: [1.0, 0.45] };
  const LADDER = [[1.6, 0.78], [1.3, 0.62], [1.1, 0.5], [1.0, 0.42], [0.85, 0.36], [0.7, 0.3], [0.55, 0.25], [0.45, 0.2]];
  let file = null, bytes = null;

  async function take(files) {
    file = files[0];
    bytes = new Uint8Array(await file.arrayBuffer());
    let pages = "?";
    try { pages = (await pdfjsLib.getDocument({ data: bytes.slice() }).promise).numPages; }
    catch (e) { return FY.toast(/password/i.test(e.message) ? "This PDF is password protected. Remove the password and try again." : "Could not open this PDF. It may be damaged.", true); }
    list.innerHTML = "";
    list.appendChild(FY.fileRow({ name: file.name, ext: "PDF", sub: pages + " page(s) · " + FY.fmtBytes(file.size) }, 0, 1, { remove: () => { file = null; ws.hidden = true; drop.hidden = false; } }));
    ws.hidden = false; drop.hidden = true;
    document.getElementById("result").hidden = true;
    const p = FY.preset();
    if (p.targetKB) target.value = p.targetKB;
  }

  async function build(scale, quality, onPage) {
    const src = await pdfjsLib.getDocument({ data: bytes.slice() }).promise;
    const out = await PDFLib.PDFDocument.create();
    for (let n = 1; n <= src.numPages; n++) {
      const page = await src.getPage(n);
      const base = page.getViewport({ scale: 1 });
      const vp = page.getViewport({ scale });
      const c = document.createElement("canvas");
      c.width = Math.max(1, Math.floor(vp.width)); c.height = Math.max(1, Math.floor(vp.height));
      const ctx = c.getContext("2d");
      ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, c.width, c.height);
      await page.render({ canvasContext: ctx, viewport: vp }).promise;
      const jpg = await (await FY.canvasToBlob(c, "image/jpeg", quality)).arrayBuffer();
      const img = await out.embedJpg(jpg);
      out.addPage([base.width, base.height]).drawImage(img, { x: 0, y: 0, width: base.width, height: base.height });
      c.width = c.height = 0;
      page.cleanup();
      if (onPage) onPage(n / src.numPages);
    }
    await src.destroy();
    return new Blob([await out.save()], { type: "application/pdf" });
  }

  async function run() {
    if (!file) return;
    const btn = document.getElementById("go"); btn.disabled = true; FY.progress(0);
    const kb = +target.value || 0;
    try {
      let blob, missed = false;
      if (kb) {
        const steps = LADDER;
        for (let i = 0; i < steps.length; i++) {
          blob = await build(steps[i][0], steps[i][1], p => FY.progress((i + p) / steps.length));
          if (blob.size <= kb * 1024) break;
          if (i === steps.length - 1) missed = true;
        }
      } else {
        const [s, q] = LEVELS[seg.level];
        blob = await build(s, q, FY.progress);
      }
      FY.progress(null);
      const name = FY.baseName(file.name) + "-compressed.pdf";
      const bigger = blob.size >= file.size;
      if (bigger && !kb) blob = file;
      const pct = Math.max(0, Math.round((1 - blob.size / file.size) * 100));
      const msg = bigger && !kb
        ? "This PDF is already well compressed, so we kept the original. Try Extreme for a smaller file."
        : missed ? "We could not reach " + kb + " KB without making pages unreadable, so this is the smallest readable version." : "";
      const r = FY.showResult("<h3>" + (pct ? "Saved " + pct + "%" : "Done") + "</h3><p class=\"muted\">" + FY.fmtBytes(file.size) + " → <b>" + FY.fmtBytes(blob.size) + "</b>" + (msg ? "<br>" + msg : "") +
        '</p><button class="btn btn-primary btn-lg" id="dl">Download PDF</button>');
      r.querySelector("#dl").addEventListener("click", () => FY.download(blob, name));
      FY.download(blob, name);
      if (pct) FY.confetti();
    } catch (e) {
      FY.progress(null);
      FY.toast("Compression failed: " + e.message, true);
    } finally { btn.disabled = false; }
  }

  FY.dropzone(drop, { accept: ["application/pdf", ".pdf"], multiple: false, label: "a PDF file", onFiles: take });
  document.getElementById("go").addEventListener("click", run);
})();
