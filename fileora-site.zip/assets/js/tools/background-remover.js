/* AI background remover in the browser: U2-Net (small) via ONNX Runtime Web. The photo never leaves the device.
   2 free cut-outs a day up to 1500 px; Pro is unlimited and keeps the full resolution. */
(function () {
  const root = document.documentElement.dataset.root || "";
  const KEY = "bg", LIMIT = 2, FREE_PX = 1500, SIZE = 320;
  const MEAN = [0.485, 0.456, 0.406], STD = [0.229, 0.224, 0.225];
  const $ = id => document.getElementById(id);
  const ws = $("ws"), drop = $("drop"), list = $("list"), edge = $("edge");
  const seg = FY.segs((n) => { if (n === "bgc") { $("colorWrap").hidden = seg.bgc !== "color"; paint(); } });
  let file = null, img = null, mask = null, out = null, session = null;
  const showLeft = () => { $("left").textContent = FY.isPro() ? "Unlimited (Pro)" : Math.max(0, LIMIT - FY.usesToday(KEY)); };

  async function take(files) {
    file = files[0];
    try { img = await FY.loadImage(file); } catch (e) { return FY.toast(e.message, true); }
    mask = null; out = null;
    list.innerHTML = "";
    list.appendChild(FY.fileRow({ name: file.name, thumb: img.src, sub: img.naturalWidth + " × " + img.naturalHeight + " · " + FY.fmtBytes(file.size) }, 0, 1,
      { remove: () => { file = null; ws.hidden = true; drop.hidden = false; $("bgOut").hidden = true; } }));
    ws.hidden = false; drop.hidden = true; $("bgOut").hidden = true;
  }

  async function getSession() {
    if (session) return session;
    ort.env.wasm.wasmPaths = new URL(root + "assets/vendor/ort/", location.href).href;
    ort.env.wasm.numThreads = self.crossOriginIsolated ? Math.min(4, navigator.hardwareConcurrency || 1) : 1;
    session = await ort.InferenceSession.create(new URL(root + "assets/models/u2netp.onnx", location.href).href, { executionProviders: ["wasm"] });
    return session;
  }

  /* Returns a SIZE×SIZE canvas whose alpha is the subject mask (0..255) */
  async function predict() {
    const c = document.createElement("canvas"); c.width = c.height = SIZE;
    const ctx = c.getContext("2d", { willReadFrequently: true });
    ctx.imageSmoothingQuality = "high";
    ctx.drawImage(img, 0, 0, SIZE, SIZE);
    const px = ctx.getImageData(0, 0, SIZE, SIZE).data;
    let max = 1;
    for (let i = 0; i < px.length; i += 4) max = Math.max(max, px[i], px[i + 1], px[i + 2]);
    const n = SIZE * SIZE, input = new Float32Array(3 * n);
    for (let i = 0; i < n; i++) for (let k = 0; k < 3; k++) input[k * n + i] = (px[i * 4 + k] / max - MEAN[k]) / STD[k];
    const s = await getSession();
    const res = await s.run({ [s.inputNames[0]]: new ort.Tensor("float32", input, [1, 3, SIZE, SIZE]) });
    const pred = res[s.outputNames[0]].data;
    let lo = Infinity, hi = -Infinity;
    for (let i = 0; i < n; i++) { lo = Math.min(lo, pred[i]); hi = Math.max(hi, pred[i]); }
    const m = document.createElement("canvas"); m.width = m.height = SIZE;
    const mctx = m.getContext("2d"), md = mctx.createImageData(SIZE, SIZE);
    for (let i = 0; i < n; i++) { md.data[i * 4 + 3] = Math.round((pred[i] - lo) / (hi - lo || 1) * 255); }
    mctx.putImageData(md, 0, 0);
    return m;
  }

  /* Cut-out at the output size: mask scaled up smoothly, then an edge curve (soft ... sharp) */
  function compose() {
    const big = FY.isPro() ? Infinity : FREE_PX;
    const s = Math.min(1, big / Math.max(img.naturalWidth, img.naturalHeight));
    const w = Math.max(1, Math.round(img.naturalWidth * s)), h = Math.max(1, Math.round(img.naturalHeight * s));
    const c = document.createElement("canvas"); c.width = w; c.height = h;
    const ctx = c.getContext("2d", { willReadFrequently: true });
    ctx.imageSmoothingQuality = "high";
    ctx.drawImage(mask, 0, 0, w, h);
    const a = ctx.getImageData(0, 0, w, h);
    ctx.clearRect(0, 0, w, h);
    ctx.drawImage(img, 0, 0, w, h);
    const d = ctx.getImageData(0, 0, w, h);
    // Edge 0 = soft ... 100 = crisp. Values above the upper cut are fully kept, below the lower cut fully removed.
    const t = +edge.value / 100, lo = 0.08 + 0.32 * t, hi = 0.7 - 0.1 * t, lut = new Uint8ClampedArray(256);
    for (let v = 0; v < 256; v++) { const x = Math.min(1, Math.max(0, (v / 255 - lo) / (hi - lo))); lut[v] = Math.round(x * x * (3 - 2 * x) * 255); }
    for (let i = 3; i < d.data.length; i += 4) d.data[i] = lut[a.data[i]];
    ctx.putImageData(d, 0, 0);
    return c;
  }

  function paint() {
    if (!mask) return;
    out = compose();
    const view = $("bgView"), vctx = view.getContext("2d");
    view.width = out.width; view.height = out.height;
    vctx.clearRect(0, 0, view.width, view.height);
    if (seg.bgc !== "none") { vctx.fillStyle = seg.bgc === "white" ? "#ffffff" : $("bgColor").value; vctx.fillRect(0, 0, view.width, view.height); }
    vctx.drawImage(out, 0, 0);
    $("bgSize").textContent = out.width + " × " + out.height + (FY.isPro() || out.width === img.naturalWidth ? "" : " (full size with Pro)");
  }

  async function run() {
    if (!file) return;
    if (!FY.canUse(KEY, LIMIT)) return FY.upgrade("You have used your " + LIMIT + " free cut-outs for today. Pro gives unlimited background removal at full resolution, with no ads.");
    const btn = $("go"); btn.disabled = true; FY.progress(0.05);
    try {
      const first = !session;
      if (first) FY.toast("Loading the AI model (about 19 MB, only the first time)...");
      await getSession(); FY.progress(0.6);
      await new Promise(r => setTimeout(r, 30));
      mask = await predict(); FY.progress(0.95);
      FY.recordUse(KEY); showLeft();
      $("bgOut").hidden = false;
      paint();
      FY.progress(null);
      $("bgOut").scrollIntoView({ behavior: "smooth", block: "center" });
      FY.confetti();
    } catch (e) {
      FY.progress(null);
      FY.toast("The AI model could not load. Check your internet connection and try again. (" + e.message + ")", true);
    } finally { btn.disabled = false; }
  }

  async function save() {
    if (!out) return;
    const v = $("bgView");
    const png = seg.bgc === "none";
    const blob = await FY.canvasToBlob(v, png ? "image/png" : "image/jpeg", 0.92);
    FY.download(blob, FY.baseName(file.name) + (png ? "-no-bg.png" : seg.bgc === "white" ? "-white-bg.jpg" : "-new-bg.jpg"));
  }

  showLeft();
  edge.addEventListener("input", () => { $("ev").textContent = edge.value; paint(); });
  $("bgColor").addEventListener("input", paint);
  FY.dropzone(drop, { accept: ["image/*", ".heic", ".heif"], multiple: false, label: "an image", onFiles: take });
  $("go").addEventListener("click", run);
  $("save").addEventListener("click", save);
})();
