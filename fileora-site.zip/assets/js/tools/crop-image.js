/* Crop image: drag box with aspect presets, rotate, save as JPG/PNG/WebP */
(function () {
  const $ = id => document.getElementById(id);
  const ws = $("ws"), drop = $("drop"), stage = $("stage"), cv = $("cv"), box = $("box"), info = $("cropInfo");
  const seg = FY.segs((n) => { if (n === "ratio") resetBox(); });
  let src = null, file = null, scale = 1, b = { x: 0, y: 0, w: 0, h: 0 };

  const ratio = () => seg.ratio === "free" ? 0 : +seg.ratio;

  async function take(files) {
    file = files[0];
    let img;
    try { img = await FY.loadImage(file); } catch (e) { return FY.toast(e.message, true); }
    src = document.createElement("canvas");
    src.width = img.naturalWidth; src.height = img.naturalHeight;
    src.getContext("2d").drawImage(img, 0, 0);
    ws.hidden = false; drop.hidden = true; $("result").hidden = true;
    layout();
  }

  function layout() {
    const maxW = stage.parentElement.clientWidth || 600, maxH = Math.max(260, window.innerHeight * 0.6);
    scale = Math.min(1, maxW / src.width, maxH / src.height);
    const dw = Math.round(src.width * scale), dh = Math.round(src.height * scale);
    const dpr = window.devicePixelRatio || 1;
    cv.width = dw * dpr; cv.height = dh * dpr; cv.style.width = dw + "px"; cv.style.height = dh + "px";
    stage.style.width = dw + "px"; stage.style.height = dh + "px";
    cv.getContext("2d").drawImage(src, 0, 0, cv.width, cv.height);
    resetBox();
  }

  function resetBox() {
    if (!src) return;
    const W = src.width * scale, H = src.height * scale, r = ratio();
    let w = W * 0.8, h = H * 0.8;
    if (r) { if (w / h > r) w = h * r; else h = w / r; }
    b = { x: (W - w) / 2, y: (H - h) / 2, w, h };
    paint();
  }

  function paint() {
    Object.assign(box.style, { left: b.x + "px", top: b.y + "px", width: b.w + "px", height: b.h + "px" });
    info.textContent = Math.round(b.w / scale) + " × " + Math.round(b.h / scale) + " px";
  }

  // Dragging: move the box, or resize from a corner
  let drag = null;
  stage.addEventListener("pointerdown", e => {
    if (!src) return;
    const h = e.target.dataset && e.target.dataset.h;
    if (!h && e.target !== box) return;
    e.preventDefault();
    stage.setPointerCapture(e.pointerId);
    drag = { h, sx: e.clientX, sy: e.clientY, b0: { ...b } };
  });
  stage.addEventListener("pointermove", e => {
    if (!drag) return;
    const W = src.width * scale, H = src.height * scale, r = ratio();
    const dx = e.clientX - drag.sx, dy = e.clientY - drag.sy, o = drag.b0;
    if (!drag.h) {
      b.x = Math.min(Math.max(0, o.x + dx), W - o.w);
      b.y = Math.min(Math.max(0, o.y + dy), H - o.h);
    } else {
      const left = drag.h.includes("w"), top = drag.h.includes("n");
      let x1 = o.x, y1 = o.y, x2 = o.x + o.w, y2 = o.y + o.h;
      if (left) x1 = Math.min(Math.max(0, o.x + dx), x2 - 20); else x2 = Math.max(Math.min(W, x2 + dx), x1 + 20);
      if (top) y1 = Math.min(Math.max(0, o.y + dy), y2 - 20); else y2 = Math.max(Math.min(H, y2 + dy), y1 + 20);
      let w = x2 - x1, h = y2 - y1;
      if (r) {
        h = w / r;
        if (top) { y1 = y2 - h; if (y1 < 0) { y1 = 0; h = y2; w = h * r; } }
        else if (y1 + h > H) { h = H - y1; w = h * r; }
        if (left) x1 = x2 - w;
      }
      b = { x: x1, y: y1, w, h };
    }
    paint();
  });
  ["pointerup", "pointercancel"].forEach(ev => stage.addEventListener(ev, () => { drag = null; }));

  $("rot").addEventListener("click", () => {
    if (!src) return;
    const c = document.createElement("canvas");
    c.width = src.height; c.height = src.width;
    const ctx = c.getContext("2d");
    ctx.translate(c.width, 0); ctx.rotate(Math.PI / 2); ctx.drawImage(src, 0, 0);
    src = c; layout();
  });
  $("newImg").addEventListener("click", () => { src = null; ws.hidden = true; drop.hidden = false; });
  window.addEventListener("resize", () => { if (src && !ws.hidden) layout(); });

  async function run() {
    if (!src) return;
    const x = Math.round(b.x / scale), y = Math.round(b.y / scale);
    const w = Math.max(1, Math.min(src.width - x, Math.round(b.w / scale))), h = Math.max(1, Math.min(src.height - y, Math.round(b.h / scale)));
    const out = document.createElement("canvas");
    out.width = w; out.height = h;
    const ctx = out.getContext("2d");
    if (seg.fmt === "image/jpeg") { ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, w, h); }
    ctx.drawImage(src, x, y, w, h, 0, 0, w, h);
    const blob = await FY.canvasToBlob(out, seg.fmt, 0.92);
    const ext = seg.fmt === "image/png" ? "png" : seg.fmt === "image/webp" ? "webp" : "jpg";
    const name = FY.baseName(file.name) + "-cropped." + ext;
    const r = FY.showResult('<h3>Cropped!</h3><p class="muted">' + w + " × " + h + " px · " + FY.fmtBytes(blob.size) + '</p><button class="btn btn-primary btn-lg" id="dl">Download ' + ext.toUpperCase() + "</button>");
    r.querySelector("#dl").addEventListener("click", () => FY.download(blob, name));
    FY.download(blob, name);
    FY.confetti();
  }

  const p = FY.preset();
  if (p.ratio) seg.set("ratio", p.ratio);
  if (p.format) seg.set("fmt", p.format);
  FY.dropzone(drop, { accept: ["image/*", ".heic", ".heif"], multiple: false, label: "a JPG, PNG, WebP or HEIC image", onFiles: take });
  $("go").addEventListener("click", run);
})();
