/* Bulk image compressor: many images, size target or quality, optional max width and renaming, one ZIP */
(function () {
  const FREE_MAX = 10;
  const $ = id => document.getElementById(id);
  const ws = $("ws"), drop = $("drop"), list = $("list"), q = $("quality");
  const items = [];
  const seg = FY.segs((n, v) => { if (n === "by") { $("kbWrap").hidden = v !== "kb"; $("qWrap").hidden = v !== "q"; } });
  q.addEventListener("input", () => { $("qv").textContent = q.value; });

  function add(files) {
    files.forEach(f => items.push({ file: f, name: f.name, ext: (f.name.split(".").pop() || "IMG").slice(0, 4).toUpperCase(), sub: FY.fmtBytes(f.size) }));
    render();
  }
  function render() {
    list.innerHTML = "";
    items.slice(0, 60).forEach((it, i) => list.appendChild(FY.fileRow(it, i, items.length, { remove: k => { items.splice(k, 1); render(); } })));
    if (items.length > 60) { const li = document.createElement("li"); li.className = "muted"; li.style.padding = "8px 12px"; li.textContent = "+ " + (items.length - 60) + " more image(s)"; list.appendChild(li); }
    const total = items.reduce((s, it) => s + it.file.size, 0);
    $("count").innerHTML = "<b>" + items.length + "</b> image(s) · " + FY.fmtBytes(total) + (!FY.isPro() && items.length > FREE_MAX ? ' · <span class="badge pro">Pro needed for more than ' + FREE_MAX + "</span>" : "");
    ws.hidden = !items.length; drop.hidden = !!items.length;
    $("result").hidden = true;
  }

  function draw(img, maxW, type) {
    const s = maxW ? Math.min(1, maxW / img.naturalWidth) : 1;
    const c = document.createElement("canvas");
    c.width = Math.max(1, Math.round(img.naturalWidth * s)); c.height = Math.max(1, Math.round(img.naturalHeight * s));
    const ctx = c.getContext("2d");
    ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, c.width, c.height);
    ctx.imageSmoothingQuality = "high";
    ctx.drawImage(img, 0, 0, c.width, c.height);
    return c;
  }
  async function toTarget(c, type, bytes) {
    for (let round = 0; round < 6; round++) {
      let lo = 0.05, hi = 0.95, fit = null;
      for (let k = 0; k < 7; k++) {
        const mid = (lo + hi) / 2, b = await FY.canvasToBlob(c, type, mid);
        if (b.size <= bytes) { fit = b; lo = mid; } else hi = mid;
      }
      if (fit) return fit;
      const smallest = await FY.canvasToBlob(c, type, 0.05);
      const s = Math.max(0.3, Math.sqrt(bytes / smallest.size) * 0.92);
      const n = document.createElement("canvas");
      n.width = Math.max(1, Math.round(c.width * s)); n.height = Math.max(1, Math.round(c.height * s));
      n.getContext("2d").drawImage(c, 0, 0, n.width, n.height);
      c = n;
    }
    return FY.canvasToBlob(c, type, 0.05);
  }

  async function run() {
    if (!items.length) return;
    if (!FY.isPro() && items.length > FREE_MAX) return FY.upgrade("Free bulk mode handles " + FREE_MAX + " images at a time. Pro compresses unlimited images in one go, with no ads.");
    const kb = seg.by === "kb" ? Math.max(5, +$("targetKb").value || 100) : 0;
    const maxW = Math.max(0, +$("maxW").value || 0), type = seg.fmt, ext = type === "image/webp" ? ".webp" : ".jpg";
    const pattern = $("rename").value.trim();
    const btn = $("go"); btn.disabled = true; FY.progress(0);
    const outs = [], used = {};
    let before = 0, after = 0, failed = 0;
    try {
      for (let i = 0; i < items.length; i++) {
        const it = items[i];
        try {
          const img = await FY.loadImage(it.file);
          const c = draw(img, maxW, type);
          const blob = kb ? await toTarget(c, type, kb * 1024) : await FY.canvasToBlob(c, type, +q.value / 100);
          let name = (pattern ? pattern.replace(/\{n\}/g, i + 1) : FY.baseName(it.name)).replace(/[\\/:*?"<>|]/g, "-") || "image-" + (i + 1);
          if (used[name]) name += "-" + (i + 1);
          used[name] = 1;
          outs.push({ name: name + ext, blob });
          before += it.file.size; after += blob.size;
          URL.revokeObjectURL(img.src);
        } catch (e) { failed++; }
        FY.progress((i + 1) / items.length);
      }
      FY.progress(null);
      if (!outs.length) return FY.toast("None of the images could be opened.", true);
      const pct = Math.max(0, Math.round((1 - after / before) * 100));
      const zipName = FY.slug + "-bulk-" + outs.length + ".zip";
      const r = FY.showResult("<h3>" + outs.length + " image(s) compressed · saved " + pct + "%</h3><p class=\"muted\">" + FY.fmtBytes(before) + " → <b>" + FY.fmtBytes(after) + "</b>" + (failed ? " · " + failed + " file(s) could not be opened" : "") +
        '</p><button class="btn btn-primary btn-lg" id="dl">Download ZIP</button>');
      r.querySelector("#dl").addEventListener("click", () => FY.zipAndDownload(outs, zipName));
      FY.zipAndDownload(outs, zipName);
      FY.confetti();
    } catch (e) { FY.progress(null); FY.toast("Bulk compression failed: " + e.message, true); }
    finally { btn.disabled = false; }
  }

  FY.dropzone(drop, { accept: ["image/*", ".heic", ".heif"], multiple: true, label: "JPG, PNG, WebP or HEIC images", onFiles: add });
  $("more").addEventListener("change", e => { add(Array.from(e.target.files)); e.target.value = ""; });
  $("clear").addEventListener("click", () => { items.length = 0; render(); });
  $("go").addEventListener("click", run);
})();
