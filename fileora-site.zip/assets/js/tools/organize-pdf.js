/* Rotate and delete PDF pages: pdf.js thumbnails, pdf-lib to save */
(function () {
  const root = document.documentElement.dataset.root || "";
  pdfjsLib.GlobalWorkerOptions.workerSrc = root + "assets/vendor/pdf.worker.min.js";
  const $ = id => document.getElementById(id);
  const ws = $("ws"), drop = $("drop"), list = $("list"), grid = $("pages");
  let file = null, bytes = null, pages = [];
  const ROT = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20 12a8 8 0 11-2.3-5.7"/><path d="M20 4v5h-5"/></svg>';
  const DEL = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>';

  async function take(files) {
    file = files[0];
    bytes = new Uint8Array(await file.arrayBuffer());
    let pdf;
    try { pdf = await pdfjsLib.getDocument({ data: bytes.slice() }).promise; }
    catch (e) { return FY.toast(/password/i.test(e.message) ? "This PDF is password protected. Remove the password and try again." : "Could not open this PDF. It may be damaged.", true); }
    list.innerHTML = "";
    list.appendChild(FY.fileRow({ name: file.name, ext: "PDF", sub: pdf.numPages + " page(s) · " + FY.fmtBytes(file.size) }, 0, 1, { remove: () => { file = null; ws.hidden = true; drop.hidden = false; grid.innerHTML = ""; } }));
    ws.hidden = false; drop.hidden = true; $("result").hidden = true;
    pages = []; grid.innerHTML = "";
    FY.progress(0);
    for (let n = 1; n <= pdf.numPages; n++) {
      const page = await pdf.getPage(n);
      const vp0 = page.getViewport({ scale: 1 });
      const vp = page.getViewport({ scale: Math.min(1, 220 / Math.max(vp0.width, vp0.height)) * 1.5 });
      const c = document.createElement("canvas");
      c.width = Math.floor(vp.width); c.height = Math.floor(vp.height);
      const ctx = c.getContext("2d"); ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, c.width, c.height);
      await page.render({ canvasContext: ctx, viewport: vp }).promise;
      const st = { rot: 0, del: false };
      const card = document.createElement("div");
      card.className = "page-thumb org";
      card.innerHTML = '<div class="org-img"><img alt="Page ' + n + '"></div><div class="row"><span>Page ' + n + '</span><span><button class="mini" data-a="rot" aria-label="Rotate page ' + n + '">' + ROT + '</button><button class="mini" data-a="del" aria-label="Remove page ' + n + '">' + DEL + "</button></span></div>";
      card.querySelector("img").src = c.toDataURL("image/jpeg", 0.8);
      card.addEventListener("click", e => {
        const b = e.target.closest("button"); if (!b) return;
        if (b.dataset.a === "rot") st.rot = (st.rot + 90) % 360;
        if (b.dataset.a === "del") st.del = !st.del;
        paint(card, st);
      });
      st.card = card;
      pages.push(st); grid.appendChild(card);
      FY.progress(n / pdf.numPages);
    }
    FY.progress(null);
    await pdf.destroy();
  }

  function paint(card, st) {
    card.querySelector("img").style.transform = "rotate(" + st.rot + "deg)";
    card.classList.toggle("removed", st.del);
    card.querySelector('[data-a="del"]').setAttribute("aria-pressed", st.del);
  }
  function all(delta) { pages.forEach(st => { st.rot = (st.rot + delta + 360) % 360; paint(st.card, st); }); }
  $("rotL").addEventListener("click", () => all(-90));
  $("rotR").addEventListener("click", () => all(90));
  $("reset").addEventListener("click", () => pages.forEach(st => { st.rot = 0; st.del = false; paint(st.card, st); }));

  async function run() {
    if (!file) return;
    const keep = pages.filter(p => !p.del).length;
    if (!keep) return FY.toast("You removed every page. Keep at least one page.", true);
    const btn = $("go"); btn.disabled = true;
    try {
      const doc = await PDFLib.PDFDocument.load(bytes, { ignoreEncryption: true });
      doc.getPages().forEach((pg, i) => {
        const st = pages[i]; if (!st || !st.rot) return;
        pg.setRotation(PDFLib.degrees((pg.getRotation().angle + st.rot) % 360));
      });
      for (let i = pages.length - 1; i >= 0; i--) if (pages[i].del) doc.removePage(i);
      const blob = new Blob([await doc.save()], { type: "application/pdf" });
      const name = FY.baseName(file.name) + "-edited.pdf";
      const removed = pages.length - keep, turned = pages.filter(p => !p.del && p.rot).length;
      const r = FY.showResult("<h3>Your PDF is ready</h3><p class=\"muted\">" + keep + " page(s) kept" + (removed ? " · " + removed + " removed" : "") + (turned ? " · " + turned + " rotated" : "") +
        '</p><button class="btn btn-primary btn-lg" id="dl">Download PDF</button>');
      r.querySelector("#dl").addEventListener("click", () => FY.download(blob, name));
      FY.download(blob, name);
      FY.confetti();
    } catch (e) { FY.toast("Could not save the PDF: " + e.message, true); }
    finally { btn.disabled = false; }
  }

  FY.dropzone(drop, { accept: ["application/pdf", ".pdf"], multiple: false, label: "a PDF file", onFiles: take });
  $("go").addEventListener("click", run);
})();
