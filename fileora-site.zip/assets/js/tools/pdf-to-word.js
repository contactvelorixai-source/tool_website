/* PDF to Word in the browser: pdf.js reads the text (with size, bold and alignment) and JSZip writes a .docx.
   "Exact look" mode puts each page into the Word file as a picture instead. Scanned pages always go in as pictures. */
(function () {
  const root = document.documentElement.dataset.root || "";
  pdfjsLib.GlobalWorkerOptions.workerSrc = root + "assets/vendor/pdf.worker.min.js";
  const KEY = "pdf2word", LIMIT = 2, FREE_MB = 10;
  const $ = id => document.getElementById(id);
  const ws = $("ws"), drop = $("drop"), list = $("list");
  const seg = FY.segs();
  let file = null, bytes = null;
  const showLeft = () => { $("left").textContent = FY.isPro() ? "Unlimited (Pro)" : Math.max(0, LIMIT - FY.usesToday(KEY)); };

  async function take(files) {
    file = files[0];
    bytes = new Uint8Array(await file.arrayBuffer());
    let pages = "?";
    try { pages = (await pdfjsLib.getDocument({ data: bytes.slice() }).promise).numPages; }
    catch (e) { file = null; return FY.toast(/password/i.test(e.message) ? "This PDF is password protected. Remove the password and try again." : "Could not open this PDF. It may be damaged.", true); }
    list.innerHTML = "";
    list.appendChild(FY.fileRow({ name: file.name, ext: "PDF", sub: pages + " page(s) · " + FY.fmtBytes(file.size) }, 0, 1, { remove: () => { file = null; ws.hidden = true; drop.hidden = false; } }));
    ws.hidden = false; drop.hidden = true; $("result").hidden = true;
  }

  /* ---------- DOCX writing ---------- */
  const esc = s => s.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F￾￿]/g, "")
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  const twip = pt => Math.round(pt * 20), emu = pt => Math.round(pt * 12700);
  const NS = 'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" ' +
    'xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" ' +
    'xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture"';

  function run(r) {
    const sz = Math.max(12, Math.min(144, Math.round(r.size * 2)));
    return "<w:r><w:rPr>" + (r.bold ? "<w:b/>" : "") + (r.italic ? "<w:i/>" : "") + '<w:sz w:val="' + sz + '"/><w:szCs w:val="' + sz + '"/></w:rPr>' +
      '<w:t xml:space="preserve">' + esc(r.text) + "</w:t></w:r>";
  }
  function para(p) {
    const pPr = "<w:pPr>" + (p.pageBreak ? "<w:pageBreakBefore/>" : "") +
      '<w:spacing w:before="' + twip(p.before || 0) + '" w:after="0" w:line="' + Math.round(240 * (p.line || 1.08)) + '" w:lineRule="auto"/>' +
      (p.indent > 0 ? '<w:ind w:left="' + twip(p.indent) + '"/>' : "") +
      (p.align && p.align !== "left" ? '<w:jc w:val="' + (p.align === "center" ? "center" : "right") + '"/>' : "") + "</w:pPr>";
    return "<w:p>" + pPr + p.runs.map(run).join("") + "</w:p>";
  }
  function picPara(img, n, pageBreak) {
    return "<w:p><w:pPr>" + (pageBreak ? "<w:pageBreakBefore/>" : "") + '<w:spacing w:before="0" w:after="0" w:line="240" w:lineRule="auto"/><w:jc w:val="center"/></w:pPr><w:r><w:drawing>' +
      '<wp:inline distT="0" distB="0" distL="0" distR="0"><wp:extent cx="' + img.cx + '" cy="' + img.cy + '"/><wp:docPr id="' + n + '" name="Page ' + n + '"/>' +
      '<a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:pic><pic:nvPicPr><pic:cNvPr id="' + n + '" name="page' + n + '.jpg"/><pic:cNvPicPr/></pic:nvPicPr>' +
      '<pic:blipFill><a:blip r:embed="' + img.rid + '"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>' +
      '<pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="' + img.cx + '" cy="' + img.cy + '"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic>' +
      "</a:graphicData></a:graphic></wp:inline></w:drawing></w:r></w:p>";
  }
  async function makeDocx(body, media, page, margin) {
    const zip = new JSZip();
    zip.file("[Content_Types].xml", '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">' +
      '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/>' +
      '<Default Extension="jpg" ContentType="image/jpeg"/>' +
      '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>' +
      '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/></Types>');
    zip.file("_rels/.rels", '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' +
      '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>' +
      '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/></Relationships>');
    zip.file("docProps/core.xml", '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/">' +
      "<dc:title>" + esc(FY.baseName(file.name)) + "</dc:title><dc:creator>" + esc(FY.brand) + "</dc:creator></cp:coreProperties>");
    zip.file("word/_rels/document.xml.rels", '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' +
      media.map(m => '<Relationship Id="' + m.rid + '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/' + m.name + '"/>').join("") + "</Relationships>");
    media.forEach(m => zip.file("word/media/" + m.name, m.data));
    const m = twip(margin);
    zip.file("word/document.xml", '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document ' + NS + "><w:body>" + (body || '<w:p/>') +
      '<w:sectPr><w:pgSz w:w="' + twip(page.w) + '" w:h="' + twip(page.h) + '"' + (page.w > page.h ? ' w:orient="landscape"' : "") + "/>" +
      '<w:pgMar w:top="' + m + '" w:right="' + m + '" w:bottom="' + m + '" w:left="' + m + '" w:header="0" w:footer="0" w:gutter="0"/></w:sectPr></w:body></w:document>');
    return zip.generateAsync({ type: "blob", mimeType: "application/vnd.openxmlformats-officedocument.wordprocessingml.document" });
  }

  /* ---------- Reading the PDF ---------- */
  async function pageImage(page, media, maxW, maxH) {
    const base = page.getViewport({ scale: 1 }), vp = page.getViewport({ scale: 2 });
    const c = document.createElement("canvas");
    c.width = Math.floor(vp.width); c.height = Math.floor(vp.height);
    const ctx = c.getContext("2d"); ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, c.width, c.height);
    await page.render({ canvasContext: ctx, viewport: vp }).promise;
    const data = await (await FY.canvasToBlob(c, "image/jpeg", 0.85)).arrayBuffer();
    const s = Math.min(maxW / base.width, maxH / base.height);
    const img = { rid: "rIdImg" + (media.length + 1), name: "page" + (media.length + 1) + ".jpg", data, cx: emu(base.width * s), cy: emu(base.height * s) };
    media.push(img);
    return img;
  }

  async function pageParagraphs(page) {
    await page.getOperatorList(); // loads fonts so their real names (with Bold / Italic) are known
    const tc = await page.getTextContent();
    const vp = page.getViewport({ scale: 1 });
    const items = [];
    for (const it of tc.items) {
      if (!it.str) continue;
      const [a, b, , d, e, f] = it.transform;
      const size = Math.hypot(a, b) || Math.abs(d) || 10;
      let fname = "";
      try { const fo = page.commonObjs.get(it.fontName); fname = (fo && fo.name) || ""; } catch (x) { /* font not loaded */ }
      const p = vp.convertToViewportPoint(e, f);
      items.push({ text: it.str, x: p[0], y: p[1], w: it.width, size, bold: /bold|black|heavy|semibold|demi/i.test(fname), italic: /italic|oblique/i.test(fname) });
    }
    if (!items.some(i => i.text.trim())) return null;

    // Lines: items whose baselines are close
    items.sort((p, q) => p.y - q.y || p.x - q.x);
    const lines = [];
    for (const it of items) {
      const ln = lines.find(l => Math.abs(l.y - it.y) < Math.max(2, Math.min(l.size, it.size) * 0.45));
      if (ln) { ln.items.push(it); ln.size = Math.max(ln.size, it.size); }
      else lines.push({ y: it.y, size: it.size, items: [it] });
    }
    lines.sort((p, q) => p.y - q.y);
    for (const l of lines) {
      l.items.sort((p, q) => p.x - q.x);
      const runs = [];
      let end = null;
      for (const it of l.items) {
        let t = it.text;
        if (end !== null && it.x - end > it.size * 0.18 && !/\s$/.test(runs.length ? runs[runs.length - 1].text : "") && !/^\s/.test(t)) t = " " + t;
        const last = runs[runs.length - 1];
        if (last && last.bold === it.bold && last.italic === it.italic && Math.abs(last.size - it.size) < 0.6) last.text += t;
        else runs.push({ text: t, bold: it.bold, italic: it.italic, size: it.size });
        end = it.x + it.w;
      }
      l.runs = runs;
      l.x = l.items[0].x;
      l.right = Math.max(...l.items.map(i => i.x + i.w));
      l.text = runs.map(r => r.text).join("");
    }
    return { lines: lines.filter(l => l.text.trim()), width: vp.width, height: vp.height };
  }

  function toParagraphs(pg, minX, body) {
    const out = [];
    let cur = null, prev = null;
    for (const l of pg.lines) {
      const mid = (l.x + l.right) / 2, span = l.right - l.x;
      const centered = Math.abs(mid - pg.width / 2) < pg.width * 0.04 && span < pg.width * 0.7 && l.x - minX > 24;
      const align = centered ? "center" : (l.x > pg.width * 0.55 && pg.width - l.right < 80 ? "right" : "left");
      const gap = prev ? l.y - prev.y : 0;
      const sameBlock = cur && prev && gap < Math.max(l.size, prev.size) * 1.65 && Math.abs(l.size - prev.size) < 1 &&
        cur.align === align && (align !== "left" || Math.abs(l.x - prev.x) < 14 || (l.x < prev.x && cur.lines === 1 && prev.x - l.x < 40));
      if (sameBlock) {
        const last = cur.runs[cur.runs.length - 1];
        const joiner = /-$/.test(last.text) ? "" : " ";
        if (/-$/.test(last.text)) last.text = last.text.slice(0, -1);
        const first = Object.assign({}, l.runs[0], { text: joiner + l.runs[0].text.replace(/^\s+/, "") });
        [first].concat(l.runs.slice(1)).forEach(r => {
          const lr = cur.runs[cur.runs.length - 1];
          if (lr.bold === r.bold && lr.italic === r.italic && Math.abs(lr.size - r.size) < 0.6) lr.text += r.text; else cur.runs.push(Object.assign({}, r));
        });
        cur.lines++;
      } else {
        const before = prev ? Math.max(0, Math.min(36, gap - prev.size * 1.2)) : 0;
        cur = { runs: l.runs.map(r => Object.assign({}, r)), align, indent: align === "left" ? Math.max(0, l.x - minX) : 0, before, lines: 1 };
        if (cur.indent < 6) cur.indent = 0;
        // A short line in a bigger font than the body reads as a heading: keep it bold
        if (l.size > body * 1.25 && l.text.length < 120) cur.runs.forEach(r => { r.bold = true; });
        out.push(cur);
      }
      prev = l;
    }
    return out;
  }

  async function convert() {
    if (!file) return;
    if (!FY.isPro() && file.size > FREE_MB * 1048576) return FY.upgrade("Free conversions take PDFs up to " + FREE_MB + " MB. Pro converts bigger files, with no daily limit.");
    if (!FY.canUse(KEY, LIMIT)) return FY.upgrade("You have used your " + LIMIT + " free conversions for today. Pro gives unlimited PDF to Word conversions, with no ads.");
    const btn = $("go"); btn.disabled = true; FY.progress(0.02);
    try {
      const pdf = await pdfjsLib.getDocument({ data: bytes.slice() }).promise;
      const first = (await pdf.getPage(1)).getViewport({ scale: 1 });
      const exact = seg.mode === "exact";
      const margin = exact ? 0 : 54;
      const page = { w: first.width, h: first.height };
      const media = [];
      let body = "", scanned = 0;
      const pages = [];
      for (let n = 1; n <= pdf.numPages; n++) {
        const pg = await pdf.getPage(n);
        pages.push({ pg, text: exact ? null : await pageParagraphs(pg) });
        FY.progress(0.02 + 0.45 * n / pdf.numPages);
      }
      // Body font size = the most common line size across the document
      const counts = {};
      pages.forEach(p => p.text && p.text.lines.forEach(l => { const k = Math.round(l.size); counts[k] = (counts[k] || 0) + l.text.length; }));
      const bodySize = +Object.keys(counts).sort((a, b) => counts[b] - counts[a])[0] || 11;
      for (let i = 0; i < pages.length; i++) {
        const { pg, text } = pages[i];
        if (!text) {
          if (!exact) scanned++;
          const img = await pageImage(pg, media, page.w - margin * 2, page.h - margin * 2 - 4);
          body += picPara(img, i + 1, i > 0);
        } else {
          const minX = Math.min(...text.lines.map(l => l.x));
          const paras = toParagraphs(text, minX, bodySize);
          paras.forEach((p, k) => { if (k === 0) { p.pageBreak = i > 0; p.before = 0; } body += para(p); });
        }
        FY.progress(0.47 + 0.48 * (i + 1) / pages.length);
      }
      const blob = await makeDocx(body, media, page, margin);
      FY.progress(null);
      FY.recordUse(KEY); showLeft();
      const name = FY.baseName(file.name) + ".docx";
      const note = exact ? "Each page is placed in Word as a picture, so it looks exactly like the PDF. Choose <b>Editable text</b> to change the words."
        : scanned ? scanned + " page(s) had no text layer (scanned), so they went in as pictures. Use <a href=\"" + FY.rootPath + "image-to-text.html\">Image to Text</a> to pull text out of scans."
        : "Text, headings, bold and alignment are kept. Tables and images are not copied in this mode; choose <b>Exact look</b> if you need the page as it is.";
      const r = FY.showResult("<h3>Your Word file is ready</h3><p class=\"muted\">" + pdf.numPages + " page(s) · " + FY.fmtBytes(blob.size) + "</p><p class=\"muted\" style=\"font-size:.9rem\">" + note + "</p>" +
        '<button class="btn btn-primary btn-lg" id="dl">Download .docx</button>');
      r.querySelector("#dl").addEventListener("click", () => FY.download(blob, name));
      FY.download(blob, name);
      FY.confetti();
    } catch (e) { FY.progress(null); FY.toast("Could not convert this PDF: " + e.message, true); }
    finally { btn.disabled = false; }
  }

  showLeft();
  FY.dropzone(drop, { accept: ["application/pdf", ".pdf"], multiple: false, label: "a PDF file", onFiles: take });
  $("go").addEventListener("click", convert);
})();
