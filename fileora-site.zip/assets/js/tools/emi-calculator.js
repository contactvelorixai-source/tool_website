/* EMI calculator with principal/interest split and yearly schedule */
(function () {
  const $ = id => document.getElementById(id);
  const inr = v => "₹" + Math.round(v).toLocaleString("en-IN");
  const seg = FY.segs(calc);
  const pairs = [["amt", "amtR"], ["rate", "rateR"]];
  pairs.forEach(([n, r]) => {
    $(n).addEventListener("input", () => { $(r).value = $(n).value; calc(); });
    $(r).addEventListener("input", () => { $(n).value = $(r).value; calc(); });
  });
  $("ten").addEventListener("input", calc);

  function calc() {
    const P = Math.max(0, +$("amt").value || 0), yr = Math.max(0, +$("rate").value || 0);
    const n = Math.max(1, Math.round((+$("ten").value || 1) * (seg.unit === "y" ? 12 : 1)));
    const r = yr / 1200;
    const emi = r ? P * r * Math.pow(1 + r, n) / (Math.pow(1 + r, n) - 1) : P / n;
    const total = emi * n, interest = total - P;
    $("emi").textContent = inr(emi);
    $("pr").textContent = inr(P); $("int").textContent = inr(interest); $("tot").textContent = inr(total);
    const share = total ? (P / total) * 100 : 100;
    $("donut").style.background = "conic-gradient(var(--sky) 0 " + share + "%, var(--coral) " + share + "% 100%)";
    // yearly schedule
    let bal = P, rows = "", yP = 0, yI = 0;
    const start = new Date();
    for (let m = 1; m <= n; m++) {
      const i = bal * r, p = Math.min(bal, emi - i);
      bal = Math.max(0, bal - p); yP += p; yI += i;
      if (m % 12 === 0 || m === n) {
        rows += "<tr><td>" + (start.getFullYear() + Math.ceil(m / 12) - 1) + "</td><td>" + inr(yP) + "</td><td>" + inr(yI) + "</td><td>" + inr(yP + yI) + "</td><td>" + inr(bal) + "</td></tr>";
        yP = yI = 0;
      }
    }
    $("sched").innerHTML = "<thead><tr><th>Year</th><th>Principal</th><th>Interest</th><th>Total paid</th><th>Balance</th></tr></thead><tbody>" + rows + "</tbody>";
  }

  const p = FY.preset();
  if (p.amount) { $("amt").value = $("amtR").value = p.amount; }
  if (p.rate) { $("rate").value = $("rateR").value = p.rate; }
  if (p.years) $("ten").value = p.years;
  calc();
})();
