/* Percentage calculator: % of, what %, % change, discount */
(function () {
  const $ = id => document.getElementById(id);
  const num = v => {
    if (!isFinite(v)) return "–";
    return (Math.round(v * 100) / 100).toLocaleString("en-IN", { maximumFractionDigits: 2 });
  };
  function calc() {
    const v = id => parseFloat($(id).value);
    const a1 = v("a1"), b1 = v("b1"), a2 = v("a2"), b2 = v("b2"), a3 = v("a3"), b3 = v("b3"), a4 = v("a4"), b4 = v("b4");
    $("r1").innerHTML = isNaN(a1) || isNaN(b1) ? "" : "<b>" + num(a1 * b1 / 100) + "</b>";
    $("r2").innerHTML = isNaN(a2) || isNaN(b2) || !b2 ? "" : "<b>" + num(a2 / b2 * 100) + "%</b>";
    if (isNaN(a3) || isNaN(b3) || !a3) $("r3").innerHTML = "";
    else {
      const ch = (b3 - a3) / Math.abs(a3) * 100;
      $("r3").innerHTML = "<b class=\"" + (ch >= 0 ? "up" : "down") + "\">" + (ch >= 0 ? "▲ " : "▼ ") + num(Math.abs(ch)) + "%</b> " + (ch >= 0 ? "increase" : "decrease") + " (" + (ch >= 0 ? "+" : "−") + num(Math.abs(b3 - a3)) + ")";
    }
    $("r4").innerHTML = isNaN(a4) || isNaN(b4) ? "" : "<b>" + num(a4 * (1 - b4 / 100)) + "</b> · you save " + num(a4 * b4 / 100);
  }
  document.querySelectorAll(".pct-card input").forEach(i => i.addEventListener("input", calc));
  calc();
})();
